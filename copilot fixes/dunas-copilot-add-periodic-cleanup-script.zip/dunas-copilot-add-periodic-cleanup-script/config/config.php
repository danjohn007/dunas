<?php
/**
 * Sistema de Control de Acceso con IoT
 * Configuración del Sistema
 */

// Configuración de zona horaria
date_default_timezone_set('America/Mexico_City');

// Configuración de errores (cambiar a 0 en producción)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Configuración de base de datos
define('DB_HOST', 'localhost');
define('DB_NAME', 'residenc_dunas');
define('DB_USER', 'residenc_dunas');
define('DB_PASS', 'Danjohn007!');
define('DB_CHARSET', 'utf8mb4');

// Configuración de la aplicación
define('APP_NAME', 'Sistema de Control de Acceso con IoT');
define('APP_VERSION', '1.0.0');

// Detección automática de URL base
function getBaseUrl() {
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
    $host = $_SERVER['HTTP_HOST'];
    $scriptName = $_SERVER['SCRIPT_NAME'];
    $baseUrl = $protocol . $host . str_replace(basename($scriptName), '', $scriptName);
    return rtrim($baseUrl, '/');
}

define('BASE_URL', getBaseUrl());

// Rutas del sistema
define('ROOT_PATH', dirname(__DIR__));
define('APP_PATH', ROOT_PATH . '/app');
define('PUBLIC_PATH', ROOT_PATH . '/public');
define('UPLOAD_PATH', PUBLIC_PATH . '/uploads');

// Configuración de sesión
ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);
ini_set('session.cookie_secure', 0); // Cambiar a 1 si se usa HTTPS

// Configuración de Shelly Pro 4PM via Cloud API
// Se utiliza el Cloud API de Shelly para control remoto del dispositivo
// sin necesidad de conexión directa por IP local

define('SHELLY_AUTH_TOKEN', 'MzgwNjRhdWlk0574CFA7E6D9F34D8F306EB51648C8DA5D79A03333414C2FBF51CFA88A780F9867246CE317003A74'); // Token de autenticación del Cloud API
define('SHELLY_DEVICE_ID', '34987A67DA6C'); // ID del dispositivo Shelly
define('SHELLY_SERVER', 'shelly-208-eu.shelly.cloud'); // Servidor Cloud de Shelly (sin puerto ni path)
define('SHELLY_API_TIMEOUT', 15); // Timeout para conexión en segundos
define('SHELLY_SWITCH_ID', 0);  // ID del switch para abrir/cerrar barrera (canal)
define('SHELLY_ENABLED', true); // Habilitado con Cloud API

// Configuración de Hikvision Bridge (PC Puente)
// El PC puente permite la comunicación entre el servidor y el dispositivo Hikvision
// que se encuentra en la red local
// IP Pública: 187.145.46.170 (obtenida de whatismyip.com)
// Firewall configurado correctamente ✅
define('HIKVISION_BRIDGE_URL', 'http://187.145.46.170:8080'); // URL del PC puente
define('HIKVISION_BRIDGE_TIMEOUT', 10); // Timeout en segundos
define('HIKVISION_USER_VALIDITY_HOURS', 1); // Horas de validez del PIN (default: 1 hora)
define('HIKVISION_ENABLED', true); // Integración habilitada

// Configuración de archivos
define('MAX_FILE_SIZE', 5 * 1024 * 1024); // 5MB
define('ALLOWED_IMAGE_TYPES', ['image/jpeg', 'image/png', 'image/jpg']);

// Constantes del sistema
define('ITEMS_PER_PAGE', 10);
define('SESSION_TIMEOUT', 3600); // 1 hora

// Incluir autoloader
require_once ROOT_PATH . '/app/helpers/Database.php';
require_once ROOT_PATH . '/app/helpers/Auth.php';
require_once ROOT_PATH . '/app/helpers/Session.php';
require_once ROOT_PATH . '/app/helpers/Validator.php';
require_once ROOT_PATH . '/app/helpers/FileUpload.php';
require_once ROOT_PATH . '/app/helpers/ShellyAPI.php';

