<?php
/**
 * Controlador Report
 */
require_once APP_PATH . '/controllers/BaseController.php';
require_once APP_PATH . '/models/AccessLog.php';
require_once APP_PATH . '/models/Transaction.php';
require_once APP_PATH . '/models/Client.php';
require_once APP_PATH . '/models/Unit.php';
require_once APP_PATH . '/models/Driver.php';

class ReportController extends BaseController {
    
    private $accessModel;
    private $transactionModel;
    private $clientModel;
    private $unitModel;
    private $driverModel;
    
    public function __construct() {
        $this->accessModel = new AccessLog();
        $this->transactionModel = new Transaction();
        $this->clientModel = new Client();
        $this->unitModel = new Unit();
        $this->driverModel = new Driver();
    }
    
    public function index() {
        Auth::requireRole(['admin', 'supervisor']);
        
        $data = [
            'title' => 'Reportes',
            'showNav' => true
        ];
        
        $this->view('reports/index', $data);
    }
    
    public function access() {
        Auth::requireRole(['admin', 'supervisor']);
        
        $dateFrom = $_GET['date_from'] ?? date('Y-m-01');
        $dateTo = $_GET['date_to'] ?? date('Y-m-d');
        
        $filters = [
            'date_from' => $dateFrom,
            'date_to' => $dateTo
        ];
        
        $accessLogs = $this->accessModel->getAll($filters);
        
        // Calcular estadísticas
        $stats = [
            'total_access' => count($accessLogs),
            'completed' => 0,
            'in_progress' => 0,
            'cancelled' => 0,
            'total_liters' => 0
        ];
        
        foreach ($accessLogs as $log) {
            $stats[$log['status']]++;
            if ($log['liters_supplied']) {
                $stats['total_liters'] += $log['liters_supplied'];
            }
        }
        
        $data = [
            'title' => 'Reporte de Accesos',
            'accessLogs' => $accessLogs,
            'stats' => $stats,
            'dateFrom' => $dateFrom,
            'dateTo' => $dateTo,
            'showNav' => true
        ];
        
        $this->view('reports/access', $data);
    }
    
    public function financial() {
        Auth::requireRole(['admin', 'supervisor']);
        
        $dateFrom = $_GET['date_from'] ?? date('Y-m-01');
        $dateTo = $_GET['date_to'] ?? date('Y-m-d');
        
        $filters = [
            'date_from' => $dateFrom,
            'date_to' => $dateTo,
            'payment_status' => 'paid'
        ];
        
        $transactions = $this->transactionModel->getAll($filters);
        
        // Calcular estadísticas
        $stats = [
            'total_transactions' => count($transactions),
            'total_revenue' => 0,
            'total_liters' => 0,
            'by_method' => [
                'cash' => 0,
                'voucher' => 0,
                'bank_transfer' => 0
            ]
        ];
        
        foreach ($transactions as $trans) {
            $stats['total_revenue'] += $trans['total_amount'];
            $stats['total_liters'] += $trans['liters_supplied'];
            $stats['by_method'][$trans['payment_method']] += $trans['total_amount'];
        }
        
        // Obtener ingresos por día
        $revenueByDay = $this->transactionModel->getRevenueByPeriod($dateFrom, $dateTo);
        
        $data = [
            'title' => 'Reporte Financiero',
            'transactions' => $transactions,
            'stats' => $stats,
            'revenueByDay' => $revenueByDay,
            'dateFrom' => $dateFrom,
            'dateTo' => $dateTo,
            'showNav' => true
        ];
        
        $this->view('reports/financial', $data);
    }
    
    public function operational() {
        Auth::requireRole(['admin', 'supervisor']);
        
        $dateFrom = $_GET['date_from'] ?? date('Y-m-01');
        $dateTo = $_GET['date_to'] ?? date('Y-m-d');
        
        // Obtener todos los accesos del período
        $filters = [
            'date_from' => $dateFrom,
            'date_to' => $dateTo,
            'status' => 'completed'
        ];
        
        $accessLogs = $this->accessModel->getAll($filters);
        
        // Estadísticas por unidad
        $unitStats = [];
        // Estadísticas por chofer
        $driverStats = [];
        // Estadísticas por tipo de cliente
        $clientTypeStats = [
            'residential' => ['count' => 0, 'liters' => 0],
            'commercial' => ['count' => 0, 'liters' => 0],
            'industrial' => ['count' => 0, 'liters' => 0]
        ];
        
        foreach ($accessLogs as $log) {
            // Por unidad
            $unitId = $log['unit_id'];
            if (!isset($unitStats[$unitId])) {
                $unitStats[$unitId] = [
                    'plate_number' => $log['plate_number'],
                    'trips' => 0,
                    'liters' => 0
                ];
            }
            $unitStats[$unitId]['trips']++;
            $unitStats[$unitId]['liters'] += $log['liters_supplied'];
            
            // Por chofer
            $driverId = $log['driver_id'];
            if (!isset($driverStats[$driverId])) {
                $driverStats[$driverId] = [
                    'driver_name' => $log['driver_name'],
                    'trips' => 0,
                    'liters' => 0
                ];
            }
            $driverStats[$driverId]['trips']++;
            $driverStats[$driverId]['liters'] += $log['liters_supplied'];
        }
        
        // Obtener clientes para estadísticas por tipo
        $clients = $this->clientModel->getAll();
        foreach ($clients as $client) {
            $clientType = $client['client_type'];
            $clientTransactions = $this->transactionModel->getAll([
                'date_from' => $dateFrom,
                'date_to' => $dateTo
            ]);
            
            foreach ($clientTransactions as $trans) {
                if ($trans['client_id'] == $client['id']) {
                    $clientTypeStats[$clientType]['count']++;
                    $clientTypeStats[$clientType]['liters'] += $trans['liters_supplied'];
                }
            }
        }
        
        $data = [
            'title' => 'Reporte Operativo',
            'unitStats' => $unitStats,
            'driverStats' => $driverStats,
            'clientTypeStats' => $clientTypeStats,
            'dateFrom' => $dateFrom,
            'dateTo' => $dateTo,
            'showNav' => true
        ];
        
        $this->view('reports/operational', $data);
    }
    
    public function exportExcel($type) {
        Auth::requireRole(['admin', 'supervisor']);
        
        $dateFrom = $_GET['date_from'] ?? date('Y-m-01');
        $dateTo = $_GET['date_to'] ?? date('Y-m-d');
        
        // Obtener los datos según el tipo de reporte
        $data = [];
        $filename = '';
        
        switch($type) {
            case 'financial':
                $filters = [
                    'date_from' => $dateFrom,
                    'date_to' => $dateTo,
                    'payment_status' => 'paid'
                ];
                $data = $this->transactionModel->getAll($filters);
                $filename = "reporte_financiero_{$dateFrom}_{$dateTo}.csv";
                $headers = ['Fecha', 'Cliente', 'Litros', 'Método de Pago', 'Monto'];
                break;
            case 'access':
                $filters = [
                    'date_from' => $dateFrom,
                    'date_to' => $dateTo
                ];
                $data = $this->accessModel->getAll($filters);
                $filename = "reporte_acceso_{$dateFrom}_{$dateTo}.csv";
                $headers = ['Fecha Entrada', 'Fecha Salida', 'Unidad', 'Chofer', 'Cliente', 'Litros', 'Estado'];
                break;
            case 'discrepancies':
                $filters = [
                    'date_from' => $dateFrom,
                    'date_to' => $dateTo,
                    'plate_discrepancy' => true
                ];
                $data = $this->accessModel->getPlateDiscrepancies($filters);
                $filename = "reporte_discrepancias_{$dateFrom}_{$dateTo}.csv";
                $headers = ['Ticket', 'Fecha Entrada', 'Cliente', 'Placa Registrada', 'Placa Detectada', 'Chofer', 'Estado'];
                break;
            case 'plateVerification':
                $filters = [
                    'date_from' => $dateFrom,
                    'date_to' => $dateTo
                ];
                $data = $this->accessModel->getAll($filters);
                $filename = "reporte_verificacion_placas_{$dateFrom}_{$dateTo}.csv";
                $headers = ['Ticket', 'Fecha Entrada', 'Cliente', 'Placa Registrada', 'Placa Detectada', 'Verificación', 'Chofer', 'Estado'];
                break;
            default:
                $this->setFlash('error', 'Tipo de reporte no válido.');
                $this->redirect('/reports');
                return;
        }
        
        // Generar archivo CSV
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        
        $output = fopen('php://output', 'w');
        
        // Escribir BOM para UTF-8
        fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));
        
        // Escribir encabezados
        fputcsv($output, $headers);
        
        // Escribir datos
        if ($type === 'financial') {
            foreach ($data as $row) {
                $methodLabels = [
                    'cash' => 'Efectivo',
                    'voucher' => 'Vales',
                    'bank_transfer' => 'Transferencia'
                ];
                fputcsv($output, [
                    date('d/m/Y H:i', strtotime($row['transaction_date'])),
                    $row['client_name'],
                    number_format($row['liters_supplied']),
                    $methodLabels[$row['payment_method']],
                    '$' . number_format($row['total_amount'], 2)
                ]);
            }
        } elseif ($type === 'access') {
            foreach ($data as $row) {
                $statusLabels = [
                    'in_progress' => 'En Progreso',
                    'completed' => 'Completado',
                    'cancelled' => 'Cancelado'
                ];
                fputcsv($output, [
                    date('d/m/Y H:i', strtotime($row['entry_datetime'])),
                    $row['exit_datetime'] ? date('d/m/Y H:i', strtotime($row['exit_datetime'])) : '-',
                    $row['plate_number'],
                    $row['driver_name'],
                    $row['client_name'],
                    $row['liters_supplied'] ? number_format($row['liters_supplied']) : '-',
                    $statusLabels[$row['status']]
                ]);
            }
        } elseif ($type === 'discrepancies') {
            foreach ($data as $row) {
                $statusLabels = [
                    'in_progress' => 'En Progreso',
                    'completed' => 'Completado',
                    'cancelled' => 'Cancelado'
                ];
                fputcsv($output, [
                    $row['ticket_code'],
                    date('d/m/Y H:i', strtotime($row['entry_datetime'])),
                    $row['client_name'],
                    $row['plate_number'],
                    $row['license_plate_reading'] ?? 'N/A',
                    $row['driver_name'],
                    $statusLabels[$row['status']]
                ]);
            }
        } elseif ($type === 'plateVerification') {
            foreach ($data as $row) {
                $statusLabels = [
                    'in_progress' => 'En Progreso',
                    'completed' => 'Completado',
                    'cancelled' => 'Cancelado'
                ];
                
                // Determinar estado de verificación
                if (empty($row['license_plate_reading'])) {
                    $verification = 'No Detectada';
                } elseif ($row['plate_discrepancy'] == 1) {
                    $verification = 'No Coincide';
                } else {
                    $verification = 'Coincide';
                }
                
                fputcsv($output, [
                    $row['ticket_code'],
                    date('d/m/Y H:i', strtotime($row['entry_datetime'])),
                    $row['client_name'],
                    $row['plate_number'],
                    $row['license_plate_reading'] ?? 'N/A',
                    $verification,
                    $row['driver_name'],
                    $statusLabels[$row['status']]
                ]);
            }
        }
        
        fclose($output);
        exit;
    }
    
    public function exportPdf($type) {
        Auth::requireRole(['admin', 'supervisor']);
        
        // Para PDF, usaremos una simple impresión HTML que el navegador puede convertir a PDF
        $dateFrom = $_GET['date_from'] ?? date('Y-m-01');
        $dateTo = $_GET['date_to'] ?? date('Y-m-d');
        
        // Reutilizar la misma vista con un parámetro para indicar modo de impresión
        if ($type === 'financial') {
            $filters = [
                'date_from' => $dateFrom,
                'date_to' => $dateTo,
                'payment_status' => 'paid'
            ];
            
            $transactions = $this->transactionModel->getAll($filters);
            
            // Calcular estadísticas
            $stats = [
                'total_transactions' => count($transactions),
                'total_revenue' => 0,
                'total_liters' => 0,
                'by_method' => [
                    'cash' => 0,
                    'voucher' => 0,
                    'bank_transfer' => 0
                ]
            ];
            
            foreach ($transactions as $trans) {
                $stats['total_revenue'] += $trans['total_amount'];
                $stats['total_liters'] += $trans['liters_supplied'];
                $stats['by_method'][$trans['payment_method']] += $trans['total_amount'];
            }
            
            $data = [
                'title' => 'Reporte Financiero - Impresión',
                'transactions' => $transactions,
                'stats' => $stats,
                'dateFrom' => $dateFrom,
                'dateTo' => $dateTo,
                'showNav' => false,
                'printMode' => true
            ];
            
            $this->view('reports/financial_print', $data);
        } elseif ($type === 'discrepancies') {
            $filters = [
                'date_from' => $dateFrom,
                'date_to' => $dateTo,
                'plate_discrepancy' => true
            ];
            
            $discrepancies = $this->accessModel->getPlateDiscrepancies($filters);
            
            // Calcular estadísticas
            $stats = [
                'total_discrepancies' => count($discrepancies),
                'by_status' => [
                    'in_progress' => 0,
                    'completed' => 0,
                    'cancelled' => 0
                ]
            ];
            
            foreach ($discrepancies as $log) {
                $stats['by_status'][$log['status']]++;
            }
            
            $data = [
                'title' => 'Reporte de Discrepancias de Placas - Impresión',
                'discrepancies' => $discrepancies,
                'stats' => $stats,
                'dateFrom' => $dateFrom,
                'dateTo' => $dateTo,
                'showNav' => false,
                'printMode' => true
            ];
            
            $this->view('reports/discrepancies_print', $data);
        } else {
            $this->setFlash('error', 'Tipo de reporte no válido para exportación PDF.');
            $this->redirect('/reports/' . $type);
        }
    }
    
    public function plateDiscrepancies() {
        Auth::requireRole(['admin', 'supervisor']);
        
        $dateFrom = $_GET['date_from'] ?? date('Y-m-01');
        $dateTo = $_GET['date_to'] ?? date('Y-m-d');
        
        $filters = [
            'date_from' => $dateFrom,
            'date_to' => $dateTo,
            'plate_discrepancy' => true
        ];
        
        $discrepancies = $this->accessModel->getPlateDiscrepancies($filters);
        
        // Obtener todos los accesos del período para calcular tasa de verificación
        $allFilters = [
            'date_from' => $dateFrom,
            'date_to' => $dateTo
        ];
        $allAccesses = $this->accessModel->getAll($allFilters);
        
        // Calcular placas verificadas (plate_discrepancy = 0)
        $platesMatched = 0;
        foreach ($allAccesses as $access) {
            if ($access['plate_discrepancy'] == 0) {
                $platesMatched++;
            }
        }
        
        // Calcular estadísticas
        $stats = [
            'total_discrepancies' => count($discrepancies),
            'total_accesses' => count($allAccesses),
            'plates_matched' => $platesMatched,
            'by_status' => [
                'in_progress' => 0,
                'completed' => 0,
                'cancelled' => 0
            ]
        ];
        
        foreach ($discrepancies as $log) {
            $stats['by_status'][$log['status']]++;
        }
        
        $data = [
            'title' => 'Reporte de Discrepancias de Placas',
            'discrepancies' => $discrepancies,
            'stats' => $stats,
            'dateFrom' => $dateFrom,
            'dateTo' => $dateTo,
            'showNav' => true
        ];
        
        $this->view('reports/plate_discrepancies', $data);
    }
    
    public function plateVerification() {
        Auth::requireRole(['admin', 'supervisor']);
        
        $dateFrom = $_GET['date_from'] ?? date('Y-m-01');
        $dateTo = $_GET['date_to'] ?? date('Y-m-d');
        
        $filters = [
            'date_from' => $dateFrom,
            'date_to' => $dateTo
        ];
        
        // Obtener accesos con placas verificadas (plate_discrepancy = 0)
        $accesses = $this->accessModel->getPlateVerifications($filters);
        
        // Debug temporal
        error_log("=== DEBUG PLATE VERIFICATION ===");
        error_log("Date From: " . $dateFrom);
        error_log("Date To: " . $dateTo);
        error_log("Total accesses with plate_discrepancy=0: " . count($accesses));
        
        // Obtener todos los accesos para estadísticas generales
        $allAccesses = $this->accessModel->getAll($filters);
        
        // Calcular estadísticas generales (de todos los accesos)
        $stats = [
            'total_accesses' => count($allAccesses),
            'plates_matched' => count($accesses), // Solo los que coincidieron
            'plates_not_matched' => 0,
            'plates_not_detected' => 0,
            'by_status' => [
                'in_progress' => 0,
                'completed' => 0,
                'cancelled' => 0
            ]
        ];
        
        // Calcular estadísticas de todos los accesos
        foreach ($allAccesses as $access) {
            $hasValidReading = !empty($access['license_plate_reading']) 
                && $access['license_plate_reading'] !== 'N/A' 
                && $access['license_plate_reading'] !== 'Placa no encontrada';
                
            if (!$hasValidReading) {
                $stats['plates_not_detected']++;
            } elseif ($access['plate_discrepancy'] == 1 || $access['plate_discrepancy'] === true || $access['plate_discrepancy'] === '1') {
                $stats['plates_not_matched']++;
            }
        }
        
        // Calcular estadísticas de estado solo de los que coincidieron
        foreach ($accesses as $access) {
            $stats['by_status'][$access['status']]++;
        }
        
        $data = [
            'title' => 'Reporte de Verificación de Placas',
            'accesses' => $accesses,
            'stats' => $stats,
            'dateFrom' => $dateFrom,
            'dateTo' => $dateTo,
            'showNav' => true
        ];
        
        $this->view('reports/plate_verification', $data);
    }
}
